<?php 
  require_once("../inclusions/header.php");
  require_once("./page_vew.php");
  require_once("../inclusions/footer.php");
?>
