<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="col-sm-12 col-md-12" style="margin-top:30px">
			<div class="title_left">
				<h1 class="main_text_second_stu my-3 font-weight-bold"> Filters for Customer, Product, and Price</h1>
      </div>
    </div>
  </div>
  <div class="clearfix"></div>

    <!-- Home image: This is a free image that I found on pixabay.com. The image is freely accessible via the link: https://pixabay.com/fr/photos/une-biblioth%C3%A8que-livres-globe-1668174/-->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
          <img src="../img/book_shop.jpg" style="height:auto; max-height:100%; max-width:100%">
      </div>
    </div>
    <!-- /Home image-->


    <!-- Filters-->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
        <div class="">
          <h3 class="main_text_second_stu font-weight-bold"><i class="fa fa-filter main_fa_stu"></i> My Filters</h3>
          <div class="clearfix"></div>
        </div>
        <div class="">
          <form class="form-horizontal form-label-left" id="AjoutMatiere">
    				<div class="form-group row">

              <!-- Customers Filter-->
              <div class="col-md-3 col-sm-3 ">
		    				<select class="form-control" name="customer" id="customer" onchange="getProducts(this.value)">
                  <option value="">Select a Customer</option>
                  <option value="all_customers">All the Customers</option>
                  <option value="no_customer">No Customer</option>
                  <?php
                      $listCustomer = $db_con -> query("SELECT customer_id, customer_name FROM customers ORDER BY customer_name ASC");
                      while($listCustomer_data = $listCustomer -> fetch(PDO::FETCH_ASSOC))
                      {
                          echo '<option value="'.$listCustomer_data['customer_id'].'">'.$listCustomer_data['customer_name'].'</option>';
                      }
                  ?>
                </select> 
						    <div id="alertCustomer"> Select a Customer <span class="required">*</span></div>
              </div>
              <!-- /Customers Filter-->
		
              <!-- Products Filter: The below selection list is automatically filled when the Custumer's choice is made -->
		          <div class="col-md-6 col-sm-6 ">
						    <select class="form-control" name="product" id="product" onchange = "getPrices($('#customer').val(), this.value)">
                  <option value="">Waiting for the Customer</option>
                </select> 
						    <div id="alertProduct"> Product <span class="required">*</span></div>
					    </div>
              <!-- /Products Filter-->
  
              <!-- Prices Filter: The below selection list is automatically filled when the Custumer's and the Product's choices are made -->
              <div class="col-md-3 col-sm-3 ">
  						  <select class="form-control" name="price" id="price" onchange="getResults($('#customer').val(), $('#product').val(), this.value)">
                  <option value="">Waiting for the Product</option>
                </select> 
			  		  	<div id="alertPrice"> Price <span class="required">*</span></div>
				    	</div>
              <!-- /Prices Filter-->

              <!-- In this Project, the HTML events are managed by JQuery, explaining why there is no submit button-->
		  	  	</div>
	  		  </form>
        </div>
      </div>
    </div>
    <!-- /Filters-->


    <!-- Results: They are showed in tables that are contained in the div having the id = boxResults -->
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
        <div class="">
          <h3 class="main_text_second_stu font-weight-bold"><i class="fa fa-database main_fa_stu"></i> Results</h3>
          <div class="clearfix"></div>
        </div>
        <div class="">
          <!-- Div containing the results-->
          <div id="boxResults"></div>
          <!-- /Div containing the results-->
        </div>
      </div>
    </div>
    <!-- /Results-->

    
</div>
<!-- /page content -->
