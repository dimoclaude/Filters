<?php 
    require_once("../inclusions/db_connexion.php");
?>

<!DOCTYPE html>
  <html lang="en">

    <!-- header-->
    <head>
      
      <!-- Meta, title, CSS, etc. -->
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="../img/logo.jpg">
      <title>My Book Shop </title>

      <!-- Bootstrap -->
      <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <link href="../build/css/complement.css" rel="stylesheet">

      <!-- Custom Theme Style  -->
      <link href="../build/css/custom.min.css" rel="stylesheet">

	  </head>
    <!-- /header-->
    

    <!-- Body-->
    <body class="nav-md ">
      <div class="container body">
        <div class="main_container">
          <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
              <div class="clearfix"></div>

                <!--menu profile quick info --> 
                <div class="profile clearfix">
                  <div class="profile_pic">
                    <span id="GetBigImgLogo"><img src="../img/logo.jpg" alt="..." class="img-circle profile_img"></span>              </div>
                    <div class="profile_info">
                    <span>Welcome to,</span>
                    <h2>My Book Shop</h2>
                  </div>
                </div>
              </div>
            </div>

            <!-- top navigation -->
            <div style="position:fixed; width:100%; z-index:100;">
              <div class="top_nav" style=" background:#fff;">
                <div class="nav_menu" style=" background:#fff;">
                  <div class="nav toggle">
                    <a id="menu_toggle"><i class="fa font-weight-bold main_fa_stu"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- /top navigation -->

