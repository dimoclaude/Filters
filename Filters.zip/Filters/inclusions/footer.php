
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
       
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
   
    <!-- Index Scripts -->
    <script src="../build/js/index.js"></script>
  </body>
</html>
