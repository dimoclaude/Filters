<?php
try 
{
    // Connexion to the database via PDO
    $db_con = new PDO('mysql:host=localhost; dbname=book_shop', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
}
catch(exception $e) 
{
    // In case of an error, print its type
    die('Error: '.$e->getMessage());
}
?>