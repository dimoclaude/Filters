<?php

    // Executing queries obtained from filters
    $list_sale = $db_con -> prepare($req);
    $list_sale -> execute($array); 

    
    // Title of filtered results
    echo '<h5 class="mb-3">List of '.$result.' </h5>';

    // Tables containing filtered results
    echo '
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    '.$th_customer_info.'
                    '.$th_product_name.'
                    '.$th_product_price.'
                    <th><i class="fa fa-clock-o main_fa_stu"></i> Sale Date</th>
                </tr>
            </thead>
            <tbody>';
                $idx = 1;
                $total_price = 0;
                while($list_sale_data = $list_sale -> fetch(PDO::FETCH_ASSOC))
                {
                    $td_product_name = ($product_id == 'all_products' || $product_id == 'all_product_customer')?'<td>'.$list_sale_data['product_name'].' </td>':'';
                    $td_product_price = ($price_id == 'all_prices' || $price_id == 'all_price_customer')?'<td>'.$list_sale_data['product_price'].' €</td>':'';
                    $td_customer_info = ($_POST['customer_id'] == 'all_customers')?'<td>'.$list_sale_data['customer_name'].' </td><td><a href="mailto:'.$list_sale_data['customer_mail'].'" target="_BLANK">'.$list_sale_data['customer_mail'].'</a></td>':'';
                    
                    // Enter results in the table
                    echo '
                    <tr>
                        <th scope="row">'.$idx.'</th>
                        '.$td_customer_info.'
                        '.$td_product_name.'
                        '.$td_product_price.'
                        <td>'.$list_sale_data['sale_date'].'</td>
                    </tr>';
                    $idx += 1;
                    $total_price += $list_sale_data['product_price'];
                } 

                echo '
                    <tr>
                        <th scope="row" colspan="'.$colspan.'" class="text-right">TOTAL PRICE</th>
                        <td>'.$total_price.' €</td>
                    </tr>';
    echo '
            </tbody>
        </table>'; 

    // End of the results

?>