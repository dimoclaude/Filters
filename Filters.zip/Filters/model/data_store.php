<?php
    /* 
        This file allows to read a JSON file with PHP and store its its data in the database book_shop
    */

    // We require the connexion to the databse to start any SQL process
    require_once("./inclusions/db_connexion.php");

    // Path to the JSON file
    $file = './sales.json'; 

    // Put the file contents in a PHP variable
    $data = file_get_contents($file); 
    
    // Decode JSON stream
    $all_sales = json_decode($data); 



    /* 
        According to our problem statement, I was able to identify four SQL tables, namely : customers, prices, products, and sales
        Customer, price and product tables are defined in normal form (1FN).
    */



    // Extraction of non-redundant customer information
    $customers = array_unique(array_column($all_sales, 'customer_name', 'customer_mail'));
    
    // Extraction of non-redundant product information
    $products = array_unique(array_column($all_sales, 'product_name', 'product_id'));

    // Extraction of non-redundant price information
    $prices = array_unique(array_column($all_sales, 'product_price', 'sale_id'));
    
    // Extraction of sale information
    $sales = array_column($all_sales, 'sale_date', 'sale_id');

    // Extraction of customer IDs
    $customer_ids = array_flip(array_keys($customers));

    // Extraction of price IDs
    $price_ids = array_flip(array_values($prices));
    
    // Extraction of foreign keys to feed the sales table
    $keys_products = array_column($all_sales, 'product_id', 'sale_id');
    $keys_customers = array_column($all_sales, 'customer_mail', 'sale_id');
    $keys_prices = array_column($all_sales, 'product_price', 'sale_id');
    

    // Insert data into the various database tables

    foreach($customers AS $customer_mail => $customer_name)
    {
        $insert_customer = $db_con -> prepare("INSERT INTO customers (customer_name, customer_mail) VALUES (:customer_name, :customer_mail)");
        $insert_customer -> execute(array('customer_name' => $customer_name, 'customer_mail' => $customer_mail));
    }

    foreach($products AS $product_name)
    {
        $insert_product = $db_con -> prepare("INSERT INTO products (product_name) VALUES (:product_name)");
        $insert_product -> execute(array('product_name' => $product_name));
    }

    foreach($prices AS $product_price)
    {
        $insert_price = $db_con -> prepare("INSERT INTO prices (product_price) VALUES (:product_price)");
        $insert_price -> execute(array('product_price' => $product_price));
    }

    foreach($sales AS $sale_id => $sale_date)
    {
        $sales = $db_con -> prepare("INSERT INTO sales (customer_id, product_id, price_id, sale_date) VALUES (:customer_id, :product_id, :price_id, :sale_date)");
        $sales -> execute(array('customer_id' => $customer_ids[$keys_customers[$sale_id]] + 1, 'product_id' => $keys_products[$sale_id], 'price_id' => $price_ids[$keys_prices[$sale_id]] + 1, 'sale_date' => $sale_date));
    }

?>