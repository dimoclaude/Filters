<?php
    /* 
        This file allows to filter the sales of the BookShop with respect to the Customer, the Product and the Price.
        Its also allows to put the corresponding results in a table whose fields change according to the filtered results
    */

    // Retrieving parameter values
    $product_id = array_key_exists('p', $_GET)?$_GET['p']:'';
    $price_id = array_key_exists('m', $_GET)?$_GET['m']:'';

    // Initialisation of the table title
    $result = '';
    
    // Initialization of table fields that can be modified
    $th_product_name = '<th><i class="fa fa-product-hunt main_fa_stu"></i> Product Name</th>';
    $th_customer_info = ' 
    <th><i class="fa fa-user main_fa_stu"></i> Customer Name</th>
    <th><i class="fa fa-envelope main_fa_stu"></i> Customer E-Mail</th>
    ';
    $th_product_price = '<th><i class="fa fa-money main_fa_stu"></i> Product Price</th>';

    //Initialization of the last line colspan. The last line corresponds to the Total price of filtered results
    $colspan = 4;

    // Connexion to the database
    require_once('../inclusions/db_connexion.php');

    // Customer Filter
    require_once('./customer_filter.php');

    // Product Filter: The results provided by this Filter do depend on those given by the Customer Filter
    require_once('./product_filter.php');

    // The below condition insures the fact that all fileds of the filters (Customer, Product, Price) are filled 
    if(!empty($product_id) AND !empty($price_id))
    {
        // Price Filter: The results provided by this Filter do depend on those given by the Customer and the Product Filters
        require_once('./price_filter.php');

        // Results obtained from the Filters: They are presented in tables whose fields vary according to the filtered results.
        require_once('./results.php');
    }
?>