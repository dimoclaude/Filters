<?php

    // Query initialization. The query can be modified according to the filtered objects
    $req = "SELECT prices.price_id, product_price, customer_name, customer_mail, 
    product_name, sale_date
    FROM sales 
    LEFT JOIN prices ON sales.price_id = prices.price_id
    LEFT JOIN customers ON sales.customer_id = customers.customer_id
    LEFT JOIN products ON sales.product_id = products.product_id
    ";

    // Initializing query parameters
    $array = array();

    // Test to determine whether the user has selected the price to be filtered
    if($product_id == 'all_products' && ($_POST['customer_id'] == 'all_customers' || $_POST['customer_id'] == 'no_customer'))
    {
        // Formulate queries based on different filtering cases
        $result = "all the Purchases";
        if($price_id == "all_prices")
        {
            $req .= " ORDER BY sale_date DESC";
        }
        else
        {
            $th_product_price = "";
            $req.= " WHERE prices.price_id = :price_id ORDER BY sale_date DESC";
            $result .= '<br> For Products coasting '.$_GET['mo'].' €';
            $array['price_id'] = $price_id;
            $colspan = 3;
        }

        if($_POST['customer_id'] == 'no_customer')
        {
            $th_customer_info = ""; 
            
            $colspan = ($price_id == "all_prices")?2:1;
            $result .= "<br> With customer hidden informations";
        }

    }
    else
    {
        $array = array('customer_id' => $_POST['customer_id']);

        if($product_id == 'all_product_customer' && $_POST['customer_id'] != 'all_customers')
        {
            $array = array('customer_id' => $_POST['customer_id']);
            $result = "Purchases of ".$_GET['c'];
            $th_customer_info = "";
            if($price_id == "all_price_customer")
            {
                $req.= " WHERE customers.customer_id = :customer_id ORDER BY sale_date DESC";
                $colspan = 2;
            }
            else
            {
                $th_product_price = "";
                $req.= " WHERE customers.customer_id = :customer_id AND prices.price_id = :price_id ORDER BY sale_date DESC";
                $result .= '<br> For Products coasting '.$_GET['mo'].' €';
                $array['price_id'] = $price_id;
                $colspan = 1;
            }
        }
        elseif($product_id != 'all_products' && $_POST['customer_id'] == 'all_customers')
        {
            $th_product_name = "";
            $array = array('product_id' => $product_id);
            $result = "Purchases of the Product <br>".$_GET['pn'];
            if($price_id == "all_price_customer")
            {
                $req.= " WHERE products.product_id = :product_id ORDER BY sale_date DESC";
                $colspan = 3;    
            }
            else
            {
                $th_product_price = "";
                $req.= " WHERE products.product_id = :product_id ORDER BY sale_date DESC";
                $result .= "<br> Coasting ".$_GET['mo']." €";
                $array = array('product_id' => $product_id);
                $colspan = 2;
            }
        }
        elseif($product_id != 'all_products' && $_POST['customer_id'] != 'all_customers')
        {
            $th_product_name = "";
            $th_customer_info = "";
            $array = array('product_id' => $product_id);
            $result = "Purchases of the Product <br> ".$_GET['pn']."<br>";
            if($price_id == "all_prices")
            {
                $req.= " WHERE products.product_id = :product_id ORDER BY sale_date DESC";
                $result .= "With customer hidden informations";
                $colspan = 1;
            }
            else if($price_id == "all_price_customer")
            {
                $req.= " WHERE products.product_id = :product_id AND customers.customer_id = :customer_id ORDER BY sale_date DESC";
                $array['customer_id'] = $_POST['customer_id'];
                $result .= "bought by ".$_GET['c'];
                $colspan = 1;
            }
            else
            {
                $th_product_price = "";
                if($_POST['customer_id'] != 'no_customer')
                {
                    $req.= " WHERE products.product_id = :product_id AND customers.customer_id = :customer_id AND prices.price_id = :price_id ORDER BY sale_date DESC";
                    $array['customer_id'] = $_POST['customer_id'];
                    $array['price_id'] = $price_id;
                    $result .= "Coasting ".$_GET['mo']." €<br> Bought by ".$_GET['c'];
                    $colspan = 1;
                }
                else
                {
                    $req.= " WHERE products.product_id = :product_id AND prices.price_id = :price_id ORDER BY sale_date DESC";
                    $array['price_id'] = $price_id;
                    $result .= "Coasting ".$_GET['mo']." €<br> With hidden customer informations";
                    $colspan = 1;
                }
            }
        }   
    }

    // End of the price filtering
?>